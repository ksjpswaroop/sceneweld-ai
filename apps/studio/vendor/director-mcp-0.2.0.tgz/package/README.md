# SceneMeld Director

SceneMeld Director turns a creative brief into an editable scene and shot plan through MCP. It compiles text prompts for AI video tools and exports planning files. This repository contains the local planning service; video rendering and the separate editor are outside this package.

**Version 0.2.0.** See [release verification and supported scope](docs/RELEASE.md).

## Install from source

Requires Node.js 22 or newer.

```sh
git clone https://github.com/ksjpswaroop/scenemeld-director.git
cd scenemeld-director
npm ci
npm run doctor
```

Configure your MCP client using the absolute path to the built entrypoint:

```json
{
  "mcpServers": {
    "scenemeld-director": {
      "command": "node",
      "args": ["/absolute/path/scenemeld-director/dist/index.js"]
    }
  }
}
```

The npm package has not been published as part of this release. For a portable install, run `npm pack` and install the tarball. Do not assume a similarly named public npm package belongs to this repository.

## Start planning

Ask your MCP client to create a 30-second scene plan for a lighthouse in a storm, using the generic prompt dialect. The default `local-mock` provider produces a deterministic structural draft without an API key. Select a live provider for specific AI-generated scenes and shots.

Plans persist automatically. Use `director_list_projects` to find saved IDs after restarting. Edit shots, run continuity checks and compile prompts again before export.

Use the [creator walkthrough and pilot feedback form](docs/CREATOR_PILOT.md) to try the complete workflow and capture feedback.

## Providers

- **local-mock:** offline structural planning and suggestions. Default.
- **openai-byok:** reads `OPENAI_API_KEY`. Uses the OpenAI Responses API, with `OPENAI_MODEL` defaulting to `gpt-4.1-mini`. Requires account access to the selected model.
- **ollama-local:** install and run Ollama, then select an installed model through `model` or `OLLAMA_MODEL`. Defaults to `http://127.0.0.1:11434`; custom URLs must be loopback origins.
- **ollama-cloud:** reads `OLLAMA_API_KEY` and requires `model` or `OLLAMA_MODEL`. Uses the official Ollama endpoint.

Use `director_set_provider` to switch for the current process. Set `SCENEMELD_PROVIDER` in the server environment to select a provider on every startup. Inject secrets through your process environment or secret manager; do not put real keys in tracked client examples or chat messages. Provider failures are reported instead of silently replacing AI output with a mock plan. Cloud planning sends the creative brief, and suggestions also send the existing project, to the selected provider.

For an existing local key file, launch Node with an explicit env-file argument. See [the OpenAI MCP configuration](examples/openai_mcp.json). Replace its example paths with your installation and key-file paths; the configuration contains no key. A key saved in .env.local is not loaded automatically by npm start.

## Tools

| Task | Tools |
| --- | --- |
| Discover | director_capabilities, director_list_projects, director_get_project |
| Plan | director_plan_intent, director_set_provider |
| Edit | director_add_scene, director_edit_scene, director_add_shot, director_edit_shot |
| Inspect | director_list_scenes, director_list_shots, director_check_continuity |
| Suggest | director_suggest_shot |
| Output | director_compile_prompts, director_export_scenemeld, director_import_scenemeld |
| Remove | director_delete_project |

Prompt formats: generic, sora, veo-3, wan-2.2, runway-gen4, kling-2.0, pika-2.0 and hailuo. These are text templates, not video generation API integrations or a guarantee of current model availability. Review duration and other model constraints in the video tool before generating.

Exported `.scenemeld.json` files retain Director planning data and a sequence projection. Director-to-Director round trips are tested. The separate SceneWeld repository currently has no project importer, so direct editor interoperability is unavailable. The directive block is the authoritative Director data; the sequential projection is for inspection and future integrations. Files are limited to 10 MB. Imports refuse to replace existing project IDs unless replace=true is explicitly supplied.

## Storage

The default state file is `~/.scenemeld-director/state.json`. Override it with `SCENEMELD_STATE_FILE`. Only one process may own a given state file. Read [operation and recovery](docs/RELEASE.md) before sharing state between clients or restoring backups.

## Development

```sh
npm run typecheck
npm run lint
npm run format:check
npm test
npm audit
npm pack
```

Tests include a real stdio MCP client that creates, saves, restarts, edits, compiles, exports, deletes and restores a project. Live provider verification requires an existing key and is tracked separately.

MIT licensed. See [LICENSE](LICENSE).
