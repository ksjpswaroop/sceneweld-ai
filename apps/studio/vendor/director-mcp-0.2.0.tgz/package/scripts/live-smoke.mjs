import { mkdtemp, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

if (!process.env.OPENAI_API_KEY)
  throw new Error('OPENAI_API_KEY is required for the live verification.');
const directory = await mkdtemp(path.join(os.tmpdir(), 'director-live-'));
const client = new Client({ name: 'director-live-verification', version: '1.0.0' });
try {
  await client.connect(
    new StdioClientTransport({
      command: process.execPath,
      args: [
        process.env.DIRECTOR_TEST_ENTRY ??
          fileURLToPath(new URL('../dist/index.js', import.meta.url)),
      ],
      env: {
        OPENAI_API_KEY: process.env.OPENAI_API_KEY,
        OPENAI_MODEL: process.env.OPENAI_MODEL ?? 'gpt-4.1-mini',
        SCENEMELD_PROVIDER: 'openai-byok',
        SCENEMELD_STATE_FILE: path.join(directory, 'state.json'),
      },
      stderr: 'pipe',
    }),
  );
  async function call(name, args = {}) {
    const result = await client.callTool({ name, arguments: args });
    if (result.isError)
      throw new Error(
        `Live verification failed at ${name}; inspect provider configuration and model access.`,
      );
    const item = result.content.find((part) => part.type === 'text');
    if (!item) throw new Error(`No text result from ${name}`);
    return JSON.parse(item.text);
  }
  const project = await call('director_plan_intent', {
    intent:
      'One scene: a ten-second cinematic view of a lighthouse beam crossing ocean waves at dusk.',
    durationSec: 10,
    targetModel: 'generic',
  });
  if (!project.evidence.some((item) => item.source.startsWith('openai-byok:')))
    throw new Error('Live plan did not use OpenAI.');
  const suggestion = await call('director_suggest_shot', {
    projectId: project.projectId,
    sceneId: project.scenes[0].sceneId,
  });
  if (suggestion.source !== 'openai-byok') throw new Error('Live suggestion did not use OpenAI.');
  for (const model of ['generic', 'sora', 'veo-3']) {
    const compiled = await call('director_compile_prompts', {
      projectId: project.projectId,
      model,
    });
    if (!compiled.count) throw new Error('No compiled shots.');
  }
  console.log(
    JSON.stringify({
      result: 'passed',
      provider: 'openai-byok',
      model: process.env.OPENAI_MODEL ?? 'gpt-4.1-mini',
      scenes: project.scenes.length,
      shots: project.scenes.reduce((sum, scene) => sum + scene.shots.length, 0),
      checks: ['live planning', 'live suggestion', 'three prompt formats'],
    }),
  );
} finally {
  await client.close();
  await rm(directory, { recursive: true, force: true });
}
