# Architecture

SceneMeld Director is a local, single-user MCP server over stdio.

- `index.ts` selects the environment-configured provider, acquires the state lock, loads plans, connects stdio and releases resources on disconnect or termination.
- `tools.ts` defines tool input JSON schemas. `server.ts` validates requests with Ajv before dispatching handlers inside serialized storage transactions.
- `director/store.ts` validates projects, returns isolated copies, writes atomic snapshots and rolls memory back on a failed transaction. One process owns each state file.
- `director/plan.ts` uses the active provider. Live output is validated before generated scenes and shots receive IDs and normalized durations. The offline planner stays available without credentials.
- `ai/` provides OpenAI Responses API and Ollama chat adapters. Requests have a timeout and response-size limit. API errors do not expose response bodies. Secrets remain in memory.
- `director/mutate.ts` edits plans and clears compiled prompts when source content changes.
- `director/compile.ts` builds eight text prompt formats, CSV and Markdown. These are templates, not renderers.
- `ipc/scenemeld.ts` exports a sequence projection with a richer Director block and imports it after validation. External editor compatibility remains unverified.

Schema version 1 is accepted. Unknown versions are rejected; there is no silent migration.

See [release status](RELEASE.md) for evidence, outstanding gates and recovery instructions.
