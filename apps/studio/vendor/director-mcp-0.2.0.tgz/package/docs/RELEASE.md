# SceneMeld Director 0.2.0 release verification

## Supported application

This release is the local, single-user SceneMeld Director MCP planning service described in the repository's original scope. It creates and edits scene/shot plans, checks continuity, compiles text prompts and exchanges Director planning files. It is not a video renderer or the separate SceneWeld editor.

The 17 tools cover discovery, AI provider selection, planning, scene and shot editing, continuity checks, suggestions, compilation, export/import and project deletion. The default offline planner works without credentials. OpenAI supplies live generation when selected.

## Verification

- 53 automated tests cover schemas, offline planning, mutations, continuity, compilers, storage, file interchange, provider failure handling and MCP dispatch.
- A real stdio MCP client verifies create/save/restart/edit/compile/export/delete/restore, including a fresh tarball installation without development dependencies.
- Type checking, lint and formatting checks pass. The dependency audit reports no known vulnerabilities.
- CI checks Node 22 and 24 on Linux, macOS and Windows. Match the release target commit to its successful [GitHub CI run](https://github.com/ksjpswaroop/scenemeld-director/actions/workflows/ci.yml).
- Live OpenAI planning and shot suggestions passed with gpt-4.1-mini. The live check also compiles the generated plan to generic, Sora and Veo prompt text. No key or generated project data is included in the evidence.
- Ollama adapters have automated contract tests; live Ollama execution was not verified in this environment.

## Distribution and limits

The GitHub draft release contains an installable npm tarball for review and publication. The repository is private. npm registry publication and marketplace submission have not been performed; this machine is not signed in to npm.

Direct editor integration is unavailable. The separate [SceneWeld repository at commit 0186125](https://github.com/ksjpswaroop/sceneweld-ai/tree/018612582d19ab9bcdaade058acf4fcae7508907) contains scaffolding and UI components, but no project schema or importer. Director interchange is supported independently. Its directive block is authoritative; its sequential projection is for inspection and future integrations.

The eight model dialects produce text templates. They do not call video-generation APIs or guarantee that a particular video model is available. Human review of generated creative output and target-model constraints remains part of the workflow.

## Reproduce verification

Run npm ci, npm run format:check, npm run lint, npm run typecheck, npm test, npm audit --audit-level=moderate and npm pack.

For live verification with an existing local environment file, run:

```sh
node --env-file=.env.local scripts/live-smoke.mjs
```

This makes two billable OpenAI requests, reports verification metadata and deletes temporary plans. Set DIRECTOR_TEST_ENTRY to an installed package's dist/index.js to verify the release artifact. The OpenAI MCP configuration example loads the key file explicitly; npm start does not automatically read .env.local.

## Storage, privacy and recovery

State defaults to ~/.scenemeld-director/state.json. Set SCENEMELD_STATE_FILE to use another absolute path. One server owns a state file at a time; configure separate files for independent clients. Successful mutation responses follow the atomic state write.

Normal client disconnects and SIGINT/SIGTERM release the lock. After an uncatchable crash, verify the owning process has stopped before removing the adjacent .lock file. Back up or restore state while the server is stopped. Invalid JSON, unknown schema versions, duplicate IDs and invalid durations are rejected rather than silently replacing plans.

Snapshots use mode 0600 on Unix; directories created by Director use 0700. Windows permissions follow the user's profile ACL. Keys remain in process memory and are not written to plan state. The local key file is ignored by Git. Cloud planning sends the brief to the selected provider; suggestions also send the existing project. Local import/export tools intentionally have the user's filesystem access and should be connected only to trusted MCP clients.

Interchange files are limited to 10 MB. Imports refuse to overwrite an existing project unless replace=true is supplied explicitly. Exports are written atomically, with sequential shot timing.

## API references

- [OpenAI structured outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Ollama chat endpoint](https://docs.ollama.com/api/chat)
- [Ollama cloud authentication](https://docs.ollama.com/cloud)
