# Creator walkthrough and pilot feedback

Use this walkthrough in an MCP client connected using the README configuration. The offline demo needs no key. It creates a structural draft; choose OpenAI using the documented key-file configuration when you want AI-generated creative content.

## Five-minute walkthrough

1. Ask: “Use SceneMeld Director to create a 30-second lighthouse-in-a-storm plan with the generic dialect. Name it Lighthouse demo. Show the project ID, scenes and shot IDs.” Save the returned project ID.
2. Ask: “In that project, edit the first shot: subject is a lighthouse keeper in a yellow raincoat; action is climbing the spiral staircase. Keep the rest of the plan. Show the updated shot.”
3. Ask: “Check continuity and explain the warnings.” Review timing, references and wardrobe warnings. A clean check does not guarantee visual consistency in generated video.
4. Ask: “Compile the whole project twice, first with sora and then veo-3, using batch=true and format=md. Show both outputs.” Confirm both contain the revised subject and action. These are prompt templates to review and paste into a video tool; this demo does not generate video.
5. Ask: “Export this project to an absolute path I choose, ending in lighthouse.scenemeld.json.” Choose a new file path because exports replace the destination file. Keep the export as a backup.
6. Restart the MCP connection, then ask: “List SceneMeld projects and retrieve Lighthouse demo. Show the first shot.” Confirm the edit survived. Ask the client to compile again if you make further edits.

For a restore rehearsal, use a disposable demo project: export it, delete that project through Director, then import the exported file. Importing while the same ID exists is rejected unless replacement is explicitly requested. Direct import into the separate SceneWeld editor is not supported.

## Optional live demonstration

After configuring OpenAI, ask the client to select openai-byok and repeat the planning step with a new project name. Then ask it to suggest a shot in one of the returned scenes. A suggestion is a proposal: review it and ask the client to add the chosen shot explicitly. Cloud requests use your API account and send the brief or existing plan to the provider.

## Pilot feedback form

Copy one form per creator. Use project aliases instead of confidential client briefs. Recruitment and paid-pilot commitments have not been completed by the software release.

- Creator alias and date:
- Existing multi-shot project and current planning method:
- Offline or live provider used:
- Minutes to connect the MCP client:
- Minutes to create, revise and export the plan:
- Did the revised shot survive restart? Yes / No; details:
- Did both prompt exports preserve the intended subject and action? Yes / No; details:
- Which continuity warnings helped? Which were missing or misleading?
- Compared with your current method, would you use this exported plan? Why?
- What prevented you from using the output in your video workflow?
- Would you commit to a paid pilot? Record the proposed deliverable, agreed price and explicit commitment separately:
- Bugs or requested changes, with reproduction steps and expected result:

The portfolio's commercial gate is three creators with existing multi-shot projects, at least two preferring the exported plan and one committing to a paid pilot. Track those outcomes from actual feedback before expanding the product; passing software checks does not establish customer demand.
