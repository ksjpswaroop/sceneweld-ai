# Intent samples

Real intents you can paste into `director_plan_intent` to demo the server end-to-end. Each one is intentionally short so an agent can pick one up and ask for a plan without further context.

## 60s cinematic intro (indie game trailer, noir)

```json
{
  "intent": "60s cinematic intro for an indie game trailer, noir tone",
  "targetModel": "veo-3",
  "durationSec": 60,
  "genre": "noir",
  "tone": "tense",
  "name": "Indie game trailer intro"
}
```

## 30s product reveal (lo-fi)

```json
{
  "intent": "a 30-second reveal video for a new minimalist water bottle, calm and warm",
  "targetModel": "sora",
  "durationSec": 30,
  "genre": "product",
  "tone": "warm"
}
```

## 90s chase scene (action)

```json
{
  "intent": "a fast 90-second car chase across a rain-slick city, with a long final beat under a bridge",
  "targetModel": "wan-2.2",
  "durationSec": 90,
  "genre": "action",
  "tone": "urgent"
}
```

## 45s contemplative (slow)

```json
{
  "intent": "a quiet 45-second meditation on a window with rain, soft and still",
  "targetModel": "generic",
  "durationSec": 45,
  "genre": "ambient",
  "tone": "still"
}
```
